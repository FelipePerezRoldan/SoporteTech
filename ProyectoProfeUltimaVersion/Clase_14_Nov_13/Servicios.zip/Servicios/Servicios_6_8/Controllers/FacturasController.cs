﻿using Servicios_6_8.Clases;
using Servicios_6_8.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace Servicios_6_8.Controllers
{
    [EnableCors(origins: "https://localhost:44387", headers: "*", methods: "*")]
    [RoutePrefix("api/Facturas")]
    [Authorize]
    public class FacturasController : ApiController
    {
        [HttpPost]
        [Route("GrabarFactura")]
        public string GrabarFactura([FromBody] FACTura factura)
        {
            clsFactura Factura = new clsFactura();
            Factura.factura = factura;
            return Factura.GrabarFactura();
        }
        [HttpGet]
        [Route("MostrarDetalleFactura")]
        public IQueryable MostrarDetalleFactura(int NumeroFactura)
        {
            clsFactura Factura = new clsFactura();
            return Factura.MostrarDetalleFactura(NumeroFactura);
        }
        [HttpDelete]
        [Route("Eliminar")]
        public string Eliminar([FromBody] FACTura factura)
        {
            clsFactura Factura = new clsFactura();
            Factura.factura = factura;
            return Factura.EliminarDetalle();
        }
    }
}