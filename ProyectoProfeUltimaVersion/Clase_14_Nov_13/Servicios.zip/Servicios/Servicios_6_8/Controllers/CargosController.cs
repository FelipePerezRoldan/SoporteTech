﻿using Servicios_6_8.Clases;
using Servicios_6_8.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace Servicios_6_8.Controllers
{
    [EnableCors(origins: "https://localhost:44387", headers: "*", methods: "*")]
    [RoutePrefix("api/Cargos")]
    public class CargosController : ApiController
    {
        [HttpGet]
        [Route("ConsultarXCodigo")]
        public CARGo ConsultarXCodigo(int Codigo)
        {
            clsCargo _cargo = new clsCargo();
            return _cargo.Consultar(Codigo);
        }
        [HttpPost]
        [Route("Insertar")]
        public string Insertar([FromBody] CARGo cargo)
        {
            clsCargo _cargo = new clsCargo();
            _cargo.cargo = cargo;
            return _cargo.Insertar();
        }
        [HttpPut]
        [Route("Actualizar")]
        public string Actualizar([FromBody] CARGo cargo)
        {
            clsCargo _cargo = new clsCargo();
            _cargo.cargo = cargo;
            return _cargo.Actualizar();
        }
        [HttpDelete]
        [Route("Eliminar")]
        public string Eliminar([FromBody] CARGo cargo)
        {
            clsCargo _cargo = new clsCargo();
            _cargo.cargo = cargo;
            return _cargo.Eliminar();
        }
    }
}