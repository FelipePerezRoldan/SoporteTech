﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Servicios_6_8.Controllers
{
    [RoutePrefix("api/Ejemplo")]
    public class EjemploController : ApiController
    {
        [HttpGet]
        [Route("ConsultarDatos")]
        public string ConsultarDatos()
        {
            return "Se hizo una consulta a la base de datos";
        }
        [HttpGet]
        [Route("Saludo")]
        public string Saludar(string Nombre)
        {
            return "Saludo a: " + Nombre;
        }
    }
}